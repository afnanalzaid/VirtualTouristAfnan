//
//  PhotoCollectionViewCell.swift
//  VirtualTouristAfnan
//
//  Created by afnan abdullah on 14/05/1440 AH.
//  Copyright © 1440 afnan abdullah. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageSelectedView: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var imageFromFlikr: UIImageView!
}
