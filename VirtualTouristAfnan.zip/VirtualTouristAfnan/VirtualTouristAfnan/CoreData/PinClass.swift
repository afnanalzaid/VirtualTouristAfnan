//
//  PinClass.swift
//  VirtualTouristAfnan
//
//  Created by afnan abdullah on 17/05/1440 AH.
//  Copyright © 1440 afnan abdullah. All rights reserved.
//

import Foundation
import CoreData

@objc(Pin)
public class Pin: NSManagedObject {
    
}

extension Pin {
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        createdDate = Date()
    }
}
