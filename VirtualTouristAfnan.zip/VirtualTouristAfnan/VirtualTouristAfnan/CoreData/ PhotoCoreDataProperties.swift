//
//   PhotoCoreDataProperties.swift
//  VirtualTouristAfnan
//
//  Created by afnan abdullah on 14/05/1440 AH.
//  Copyright © 1440 afnan abdullah. All rights reserved.
//


import Foundation
import CoreData


extension Photo {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photo> {
        return NSFetchRequest<Photo>(entityName: "Photo")
    }
    
    @NSManaged public var createdDate: Date?
    @NSManaged public var id: String?
    @NSManaged public var imageData: Data?
    @NSManaged public var imageURL: String?
    @NSManaged public var pin: Pin?
    
}

