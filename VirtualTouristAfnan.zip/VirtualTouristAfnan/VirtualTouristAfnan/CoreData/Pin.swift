//
//  Pin+Extensions.swift
//  VirtualTouristAfnan
//
//  Created by afnan abdullah on 14/05/1440 AH.
//  Copyright © 1440 afnan abdullah. All rights reserved.
//

import Foundation
import CoreData

extension Pin {
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
}
