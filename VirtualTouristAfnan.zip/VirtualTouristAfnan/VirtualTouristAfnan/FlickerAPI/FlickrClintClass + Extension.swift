//
//  FlickrClient.swift
//  VirtualTouristAfnan
//
//  Created by afnan abdullah on 15/05/1440 AH.
//  Copyright © 1440 afnan abdullah. All rights reserved.
//

import Foundation
class Client : NSObject {

    var session = URLSession.shared
    override init() {
        super.init()
    }
    func bboxString(latitude: Double, longitude: Double) -> String {
        
        let minimumLon = max(longitude - Client.SearchBBoxHalfWidth, Client.SearchLonRange.0)
        let minimumLat = max(latitude  - Client.SearchBBoxHalfHeight, Client.SearchLatRange.0)
        let maximumLon = min(longitude + Client.SearchBBoxHalfWidth, Client.SearchLonRange.1)
        let maximumLat = min(latitude  + Client.SearchBBoxHalfHeight, Client.SearchLatRange.1)
        return "\(minimumLon),\(minimumLat),\(maximumLon),\(maximumLat)"
    }
    func taskForGETMethod<D: Decodable>(parameters: [String:AnyObject],decode:D.Type, completionHandlerForGET: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        var parametersWithApiKey = parameters
        var request = NSMutableURLRequest(url: tmdbURLFromParameters(parametersWithApiKey))
        let task = session.dataTask(with: request as URLRequest) { (data, response, error) in
            
            func sendError(_ error: String) {
                print(error)
                let userInfo = [NSLocalizedDescriptionKey : error]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: userInfo))
            }
            guard (error == nil) else {
                sendError("\(error!.localizedDescription)")
                return
            }
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                sendError("Your request returned a status code other than 2xx!")
                return
            }
            guard let data = data else {
                sendError("Could not retrieve data")
                return
            }
            
            self.convertDataWithCompletionHandler(data, decode:decode,completionHandlerForConvertData: completionHandlerForGET)
            
        }
        task.resume()
        return task
    }
 
    private func convertDataWithCompletionHandler<D: Decodable>(_ data: Data,decode:D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
        do {
            let obj = try JSONDecoder().decode(decode, from: data)
            completionHandlerForConvertData(obj as AnyObject, nil)
            
        } catch {
            let userInfo = [NSLocalizedDescriptionKey : "Could not parse the data as JSON: '\(data)'"]
            completionHandlerForConvertData(nil, NSError(domain: "convertDataWithCompletionHandler", code: 1, userInfo: userInfo))
        }
        
    }

    private func tmdbURLFromParameters(_ parameters: [String:AnyObject]) -> URL {
        var components = URLComponents()
        components.scheme = Client.Constants.ApiScheme
        components.host = Client.Constants.ApiHost
        components.path = Client.Constants.ApiPath
        components.queryItems = [URLQueryItem]()
        for (key, value) in parameters {
            let queryItem = URLQueryItem(name: key, value: "\(value)")
            components.queryItems!.append(queryItem)
        }
        let url = components.url!
        return url
    }

    class func sharedInstance() -> Client {
        struct Singleton {
            static var sharedInstance = Client()
        }
        return Singleton.sharedInstance
    }
}

extension Client {
    
    struct Constants {
        
        static let ApiScheme = "https"
        static let ApiHost = "api.flickr.com"
        static let ApiPath = "/services/rest"
        
    }
    
    static let SearchBBoxHalfWidth = 0.2
    static let SearchBBoxHalfHeight = 0.2
    static let SearchLatRange = (-90.0, 90.0)
    static let SearchLonRange = (-180.0, 180.0)
   
    struct ParameterKeys {
        static let Method = "method"
        static let APIKey = "api_key"
        static let Format = "format"
        static let NoJSONCallback = "nojsoncallback"
        static let Extras = "extras"
        static let SafeSearch = "safe_search"
        static let PhotosPerPage = "per_page"
        static let BoundingBox = "bbox"
        
        
    }
    
    struct ParameterValues {
        static let SearchMethod = "flickr.photos.search"
        static let APIKey = "44c56d2c6e40a6e7c0c350e15bebdabe"
        static let ResponseFormat = "json"
        static let DisableJSONCallback = "1"
        static let MediumURL = "url_m"
        static let UseSafeSearch = "1"
        static let PhotosPerPage = "21"
        
    }
    
    
}


extension Client {
    func getPhotosFormFlicker(latitude:Double ,longitude:Double, _ completionHandlerForFlickerPhoto: @escaping (_ success: Bool,_ photoData: [Any]?,_   :String?, _ errorString: String?) -> Void) {
        let bBox = self.bboxString(latitude: latitude, longitude: longitude)
        let parameters = [
            Client.ParameterKeys.Method           : Client.ParameterValues.SearchMethod
            , Client.ParameterKeys.APIKey         : Client.ParameterValues.APIKey
            , Client.ParameterKeys.Format         : Client.ParameterValues.ResponseFormat
            , Client.ParameterKeys.Extras         : Client.ParameterValues.MediumURL
            , Client.ParameterKeys.NoJSONCallback : Client.ParameterValues.DisableJSONCallback
            , Client.ParameterKeys.SafeSearch     : Client.ParameterValues.UseSafeSearch
            , Client.ParameterKeys.BoundingBox    : bBox
            , Client.ParameterKeys.PhotosPerPage  : Client.ParameterValues.PhotosPerPage
            ] as [String : Any]
        let requst = taskForGETMethod( parameters: parameters as [String : AnyObject] , decode: FlikerResbonse.self) { (result, error) in
            if let error = error {
                completionHandlerForFlickerPhoto(false ,nil ,nil,"\(error.localizedDescription)")
            }else {
                let newResult = result as! FlikerResbonse
                let resultData = newResult.photos.photo
                if newResult.photos.photo.isEmpty {
                    let noPhotoMessage = "This pin has no images!"
                    completionHandlerForFlickerPhoto(true ,nil ,noPhotoMessage,nil)
                } else {
                    completionHandlerForFlickerPhoto(true ,resultData,nil,nil)
                }
                
            }
        }
        
    }
    
    
    
    
    
}



